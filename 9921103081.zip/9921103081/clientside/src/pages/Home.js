import React from 'react'

function Home() {
  return (
    <div>
      hello afford
    </div>
  )
}

export default Home
