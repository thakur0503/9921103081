const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const bcrypt = require('bcryptjs');
const multer= require('multer');
const path= require('path');

require('dotenv').config();
const app = express();


app.use(express.json());
app.use(cors({
  credentials: true,
  origin: 'http://localhost:3000',
}));
app.use(express.static('public'));

mongoose.connect(process.env.MONGO_URL)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Error connecting to MongoDB:', err));